package com.lib.x5web;

public interface X5JavaScriptFunction {
	void onJsFunctionCalled(String tag);
}
