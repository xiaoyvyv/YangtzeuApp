package com.yangtzeu.model.imodel;


import android.app.Activity;

import com.yangtzeu.ui.view.NewsView2;

public interface INewsModel2 {

    void loadNewsData(Activity activity, NewsView2 view);

}
