package com.yangtzeu.ui.activity;

import android.os.Bundle;
import android.support.v7.widget.Toolbar;

import com.yangtzeu.R;
import com.yangtzeu.entity.GradeBean;
import com.yangtzeu.presenter.ChartPresident;
import com.yangtzeu.ui.activity.base.BaseActivity;
import com.yangtzeu.ui.view.ChartView;
import com.yangtzeu.utils.MyUtils;

import java.util.List;

import lecho.lib.hellocharts.view.ColumnChartView;
import lecho.lib.hellocharts.view.LineChartView;


public class ChartActivity extends BaseActivity implements ChartView {

    private List<GradeBean> datas;
    private Toolbar toolbar;
    private LineChartView mLineChartView;
    private ColumnChartView mColumnChartView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        datas = ((GradeBean) getIntent().getSerializableExtra("data")).getGradeBeans();
        setContentView(R.layout.activity_chart);
        super.onCreate(savedInstanceState);
        MyUtils.setToolbarBackToHome(this, toolbar);
    }

    @Override
    public void findViews() {
        toolbar = findViewById(R.id.toolbar);
        mLineChartView = findViewById(R.id.mLineChartView);
        mColumnChartView = findViewById(R.id.mColumnChartView);

    }

    @Override
    public void setEvents() {
        ChartPresident president = new ChartPresident(this, this);
        president.setChart();
        president.setColumnChart();



    }

    @Override
    public LineChartView getLineChartView() {
        return mLineChartView;
    }

    @Override
    public ColumnChartView getColumnChartView() {
        return mColumnChartView;
    }

    @Override
    public List<GradeBean> getData() {
        return datas;
    }
}
