package com.yangtzeu.http;

public class OkhttpError {
    public  static final String ERROR_LOGIN_SCHOOL_INTERNET = "请先登录校园网";
    public  static final String ERROR_NO_INTERNET = "没有网络连接";
    public static final String ERROR_LOAD = "网络连接失败";
    public static final String ERROR_FAILURE = "服务器请求错误";
    public static final String ERROR_SCHOOL_HOST = "10.151.0.249";
}
