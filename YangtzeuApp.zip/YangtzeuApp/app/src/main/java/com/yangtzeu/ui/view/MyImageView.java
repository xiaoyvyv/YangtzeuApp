package com.yangtzeu.ui.view;

public interface MyImageView {
}
