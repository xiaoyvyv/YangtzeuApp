package com.yangtzeu.ui.fragment;

import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.v7.widget.Toolbar;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.scwang.smartrefresh.layout.SmartRefreshLayout;
import com.scwang.smartrefresh.layout.api.RefreshLayout;
import com.scwang.smartrefresh.layout.listener.OnRefreshListener;
import com.yangtzeu.R;
import com.yangtzeu.presenter.MinePresenter;
import com.yangtzeu.ui.activity.base.BaseFragment;
import com.yangtzeu.ui.view.MineView;

/**
 * Created by Administrator on 2018/3/6.
 */

public class MineFragment extends BaseFragment implements MineView {
    // 标志位，标志已经初始化完成。
    private boolean isPrepared=false;
    private View rootView;
    private TextView userName;
    private TextView mClass;
    private ImageView userHeader;
    private Toolbar toolbar;
    private MinePresenter presenter;
    private SmartRefreshLayout refreshLayout;

    private TextView userNumberView;
    private TextView email;
    private TextView message;
    private LinearLayout messageLayout;
    private TextView messageImage;
    private LinearLayout changeLayout;

    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        rootView = inflater.inflate(R.layout.fragment_mine, container, false);
        findViews();
        isPrepared = true;
        lazyLoad();
        return rootView;
    }

    @Override
    public void findViews() {
        toolbar = rootView.findViewById(R.id.toolbar);
        userName = rootView.findViewById(R.id.userName);
        mClass = rootView.findViewById(R.id.mClass);
        userHeader = rootView.findViewById(R.id.userHeader);
        refreshLayout = rootView.findViewById(R.id.refreshLayout);


        userNumberView = rootView.findViewById(R.id.user_number);
        email = rootView.findViewById(R.id.email);
        message = rootView.findViewById(R.id.message);
        messageLayout = rootView.findViewById(R.id.messageLayout);
        messageImage = rootView.findViewById(R.id.messageImage);
        changeLayout = rootView.findViewById(R.id.changeLayout);




    }

    @Override
    public void setEvents() {
        refreshLayout.setEnableLoadMore(false);
        presenter = new MinePresenter(getActivity(), this);

        userHeader.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                presenter.showChangeHeaderView();
            }
        });


        refreshLayout.setEnableLoadMore(false);
        refreshLayout.setOnRefreshListener(new OnRefreshListener() {
            @Override
            public void onRefresh(RefreshLayout refreshLayout) {
                setEvents();
                presenter.loadUserInfo();
                presenter.loadMessage();
            }
        });

        refreshLayout.autoRefresh();
    }

    @Override
    protected void lazyLoad() {
        if(!isPrepared || !isVisible) {
            return;
        }
        if (!isLoadFinish) {
            setEvents();
            isLoadFinish = true;
        }
    }


    @Override
    public ImageView getHeader() {
        return userHeader;
    }

    @Override
    public TextView getClassView() {
        return mClass;
    }

    @Override
    public TextView getNameView() {
        return userName;
    }

    @Override
    public Toolbar getToolbar() {
        return toolbar;
    }

    @Override
    public TextView getUserNumberView() {
        return userNumberView;
    }

    @Override
    public TextView getEmailView() {
        return email;
    }

    @Override
    public TextView getMessageView() {
        return message;
    }

    @Override
    public LinearLayout getMessageLayout() {
        return messageLayout;
    }

    @Override
    public TextView getMessageImage() {
        return messageImage;
    }

    @Override
    public SmartRefreshLayout getRefresh() {
        return refreshLayout;
    }
}
