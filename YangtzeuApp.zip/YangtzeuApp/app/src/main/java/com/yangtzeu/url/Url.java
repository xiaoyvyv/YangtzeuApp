package com.yangtzeu.url;

public class Url {
    public static final String Default_Term = "49";
    public static final String Default_Test_Term = "48";
    public static final String Default_ExamBatch_ID = "49";

    //mob的Key
    private static String key = "20588bd8fbea0";

    //长江大学主页
    public static String Yangtzeu_Url = "http://www.yangtzeu.edu.cn/";

    public static String Yangtzeu_Base_Url = "http://jwc3.yangtzeu.edu.cn";

    //长江大学教务处主页
    public static String Yangtzeu_Home = "http://221.233.24.23/";
    //旧教务处主页
    public static String Yangtzeu_JWC = "http://jwc.yangtzeu.edu.cn/";


    /**
     * 学生相关
     */
    //登录接口
    public static String Yangtzeu_Login_Path = Yangtzeu_Base_Url + "/eams/login.action";
    //验证码地址
    public static String Yangtzeu_Login_Code = Yangtzeu_Base_Url + "/eams/captcha/image.action";
    //注销地址
    public static String Yangtzeu_Out = Yangtzeu_Base_Url + "/eams/logout.action";

    /**
     * 教务处各类网址
     */
    //学籍信息
    public static String Yangtzeu_XueJI = Yangtzeu_Base_Url + "/eams/stdDetail.action";
    //学生成绩
    public static String Yangtzeu_Grade_Url = Yangtzeu_Base_Url + "/eams/teach/grade/course/person!search.action?semesterId=";
    //学生所有成绩
    public static String Yangtzeu_AllGrade_Url = Yangtzeu_Base_Url + "/eams/teach/grade/course/person!historyCourseGrade.action?projectType=MAJOR";
    //修改密码
    public static String Yangtzeu_Change_Password = Yangtzeu_Base_Url + "/eams/security/my!save.action";
    //控制面板
    public static String Yangtzeu_Control = Yangtzeu_Base_Url + "/eams/security/my.action";
    //Cet查询
    public static String Yangtzeu_Cet = Yangtzeu_Base_Url + "/eams/stdOtherExamSignUp.action";
    //Cet查询
    public static String Yangtzeu_Guan_Cet = "http://cet.etest.net.cn/";
    //Cet报名
    public static String Yangtzeu_Cet_Add = Yangtzeu_Base_Url + "/eams/stdOtherExamSignUp!configList.action";
    //课表查询
    public static String Yangtzeu_Table = Yangtzeu_Base_Url + "/eams/courseTableForStd!courseTable.action";
    //课表查询ids
    public static String Yangtzeu_Table_Ids = Yangtzeu_Base_Url + "/eams/courseTableForStd.action";
    //我的考试
    public static String Yangtzeu_My_Test = Yangtzeu_Base_Url + "/eams/stdExamTable.action";
    //我的考试详情
    public static String Yangtzeu_My_Details_Test = Yangtzeu_Base_Url + "/eams/stdExamTable!examTable.action?examBatch.id=";
    //评教
    public static String Yangtzeu_Teacher = Yangtzeu_Base_Url + "/eams/quality/stdEvaluate.action";
    //选课查询
    public static String Yangtzeu_ChooseClass = Yangtzeu_Base_Url + "/eams/stdElectCourse.action";
    //培养计划
    public static String Yangtzeu_Personal_Plan = Yangtzeu_Base_Url + "/eams/myPlan.action";
    //专业培养计划
    public static String Yangtzeu_Major_Mode = Yangtzeu_Base_Url + "/eams/stdMajorPlan!search.action";
    //制定培养计划
    public static String Yangtzeu_Maker_Mode = Yangtzeu_Base_Url + "/eams/draftPersonalPlan.action";
    //我的培养方案
    public static String Yangtzeu_Me_Mode = Yangtzeu_Base_Url + "/eams/myDraftPersonalPlan!search.action";
    //我的培养方案详情
    public static String Yangtzeu_Me_Mode_Details = Yangtzeu_Base_Url + "/eams/myDraftPersonalPlan!info.action";
    //站内消息
    public static String Yangtzeu_ZhanNei = Yangtzeu_Base_Url + "/eams/systemMessageForStd!search.action";
    //成绩导出
    public static String Yangtzeu_Grade_Export =  Yangtzeu_Base_Url + "/eams/postgraduate/midterm/stdExamine!export.action";


    //长大新闻搜索
    public static String Yangtzeu_News_Search = "http://news.yangtzeu.edu.cn/plus/search.php?searchtype=titlekeyword&q=";
    //计算机二级成绩
    public static String Yangtzeu_Computer_Grade = "http://cjcx.neea.edu.cn/html1/folder/1508/206-1.htm?sid=300";
    //一卡通登录
    public static String Yangtzeu_CenterCard_Login = "http://ykt.yangtzeu.edu.cn/Login.aspx";

    /**
     * 教务动态
     */
    //教务通知
    public static String Yangtzeu_JWTZ = "http://jwc.yangtzeu.edu.cn/jwnews/jwxw/jwtz/index.html";
    //本周事务
    public static String Yangtzeu_BZSW = "http://jwc.yangtzeu.edu.cn/jwnews/jwxw/bzsw/index.html";
    //教学动态
    public static String Yangtzeu_JXDT = "http://jwc.yangtzeu.edu.cn/jwnews/jwxw/jxdt/index.html";
    //教学简报
    public static String Yangtzeu_JXJB = "http://jwc.yangtzeu.edu.cn/jwnews/jwxw/jxjb/index.html";

    /**
     * 下载中心
     */
    //学院下载
    public static String Yangtzeu_XYXZ = "http://jwc.yangtzeu.edu.cn/jwnews/xzzx/xyxz/";
    //教师下载
    public static String Yangtzeu_JSXZ = "http://jwc.yangtzeu.edu.cn/jwnews/xzzx/jsxz/";
    //学生下载
    public static String Yangtzeu_XSXZ = "http://jwc.yangtzeu.edu.cn/jwnews/xzzx/xsxz/";

    public static final String Yangtzeu_News_Header="http://news2.yangtzeu.edu.cn";

    /**
     * Me界面
     */
    public static String MeBackGround = "http://p04pfl7p6.bkt.clouddn.com/App/me_bg.jpg";

    /**
     * 关于界面
     */
    public static String Yangtzeu_Image_QQ = "http://p04pfl7p6.bkt.clouddn.com/App/QQ.jpg";
    public static String Yangtzeu_Image_WX = "http://p04pfl7p6.bkt.clouddn.com/App/WeiXin.jpg";
    //AppAlert通知地址
    public static String Yangtzeu_Music = "http://p04pfl7p6.bkt.clouddn.com/App/me_music.mp3";
    //我的App列表
    public static final String Yangtzeu_MyApp = "http://m.xyll520.top/MyApp.json";
    //我的游戏列表
    public static final String Yangtzeu_Games = "http://m.xyll520.top/newyangtzeu/app_json/Game.json";

    /**
     * 收藏图标
     */
    public static String Yangtzeu_Image_LIB = "http://p04pfl7p6.bkt.clouddn.com/App/Lib.jpeg";
    public static String Yangtzeu_Image_Web = "http://p04pfl7p6.bkt.clouddn.com/App/Web.jpg";
    public static String Yangtzeu_Image_WeChat = "http://p04pfl7p6.bkt.clouddn.com/App/WeChat.png";
    public static String Yangtzeu_Image_JWC = "http://p04pfl7p6.bkt.clouddn.com/App/yangtzeu.jpg";


    /**
     * 所有网站集合
     */
    //所有网站
    public static String Yangtzeu_AllWeb_Url = "http://m.xyll520.top/newyangtzeu/app_json/AllWeb.json";

    /**
     * App相关
     */
    //App酷安下载地址
    public static String AppDownUrl = "https://www.coolapk.com/apk/com.yangtzeu";
    //App更新地址
    public static String Yangtzeu_AppUp_Url = "http://m.xyll520.top/newyangtzeu/app_up/checkversion.json";
    //App通知地址
    public static String Yangtzeu_AppNotice = "http://m.xyll520.top/newyangtzeu/app_json/Notice.json";
    //AppAlert通知地址
    public static String Yangtzeu_AppAlertNotice = "http://m.xyll520.top/newyangtzeu/app_json/AlertMessage.json";
    //App导航信息
    public static String Yangtzeu_AppTripInfo = "http://m.xyll520.top/newyangtzeu/app_up/trip.json";
    //主页更多
    public static String Yangtzeu_Home_More = "http://m.xyll520.top/newyangtzeu/app_json/More.json";
    //广告
    public static String Yangtzeu_AD = "http://m.xyll520.top/newyangtzeu/app_json/AD.json";
    //JwcNotice通知地址
    public static String Yangtzeu_JwcNotice = "http://m.xyll520.top/newyangtzeu/app_json/JwcNotice.json";
    //检查App是否失效
    public static String Yangtzeu_App_CanUse = "http://m.xyll520.top/newyangtzeu/app_json/CanUse.json";
    //App反馈地址
    public static String Yangtzeu_App_FeedBack = "http://m.xyll520.top/newyangtzeu/app_php/feedback.php";
    //发邮件
    public static String Yangtzeu_App_SendEmail = "http://m.xyll520.top/php_mail/mail.php";
    //反馈
    public static String Yangtzeu_App_ShowFeedBack = "http://m.xyll520.top/newyangtzeu/app_php/showfeedback.php";
    //当前在线人数
    public static String Yangtzeu_App_Online = "http://m.xyll520.top/newyangtzeu/app/online.php";
    //当前在线人数详情
    public static String Yangtzeu_App_Online_Details = "http://m.xyll520.top/newyangtzeu/app/online_details.php";



    //获取通知消息
    public static String getMessage() {
        return "http://ll.xyll520.top/user_system/message.php?action=query_message&submit=do";
    }

    //设置通知消息已读
    public static String getReadMessage(String id) {
        return "http://ll.xyll520.top/user_system/message.php?action=set_read&submit=do"
                +"&id="+id;
    }
/*

    public static String Yangtzeu_Class =Yangtzeu_Base_Url+  "/eams/stdElectCourse!data.action";
    public static String Yangtzeu_CourseId = Yangtzeu_Base_Url+ "/eams/stdElectCourse!courseI18N.action?profileId=152&lang=zh";
    public static String Yangtzeu_RoomId = Yangtzeu_Base_Url+ "/eams/stdElectCourse!classroomI18N.action";
    public static String Yangtzeu_TeacherId = Yangtzeu_Base_Url+ "/eams/stdElectCourse!teacherI18n.action";
    public static String Yangtzeu_NowChoose =Yangtzeu_Base_Url+  "/eams/stdElectCourse!queryStdCount.action?lang=zh&projectId=1&semesterId=";
*/

    public static String Yangtzeu_Class = "http://p04pfl7p6.bkt.clouddn.com/App/m_choose_class.json";
    public static String Yangtzeu_CourseId = "http://p04pfl7p6.bkt.clouddn.com/App/m_choose_course.json";
    public static String Yangtzeu_RoomId = "http://p04pfl7p6.bkt.clouddn.com/App/m_choose_room.json";
    public static String Yangtzeu_TeacherId = "http://p04pfl7p6.bkt.clouddn.com/App/m_choose_teacher.json";
    public static String Yangtzeu_NowChoose = Yangtzeu_Base_Url + "/eams/stdElectCourse!queryStdCount.action?lang=zh&projectId=1&semesterId=";


    //App留言板--发表
    public static String Yangtzeu_App_Message = "http://m.xyll520.top/newyangtzeu/app_php/message.php";
    public static String Yangtzeu_App_ShowMessage = "http://m.xyll520.top/newyangtzeu/app_php/showmessage.php";
    //App留言板--回复
    public static String Yangtzeu_App_Reply_Message = "http://m.xyll520.top/newyangtzeu/app_php/reply.php";
    public static String Yangtzeu_App_ShowReply_Message = "http://m.xyll520.top/newyangtzeu/app_php/showreply.php";
    //App推荐公众号
    public static String Yangtzeu_App_Room1 = "http://m.xyll520.top/newyangtzeu/app_img/room_yangtzeu.jpg";
    public static String Yangtzeu_App_Room2 = "http://m.xyll520.top/newyangtzeu/app_img/room_xiaoyv.jpg";


    //封号相关
    public static String Yangtzeu_FengHao = "http://ll.xyll520.top/yangtzeu/api/ban_user.php?action=add_ban_user&submit=do&number=201603246&name=why";
    public static String Yangtzeu_RemoveFengHao = "http://ll.xyll520.top/yangtzeu/api/ban_user.php?action=delete_ban_user&submit=do&id=2";
    public static String Yangtzeu_ShowBanUser = "http://ll.xyll520.top/yangtzeu/api/ban_user.php?action=query_ban_user&submit=do";


    /**
     * 图书馆相关
     */
    public static String Yangtzeu_Search_Defeat = "http://calis.yangtzeu.edu.cn:8000/opac/search?q=";
    public static String Yangtzeu_Search_Title = "http://calis.yangtzeu.edu.cn:8000/opac/search?searchWay=title&q=";
    public static String Yangtzeu_Search_Author = "http://calis.yangtzeu.edu.cn:8000/opac/search?searchWay=author&q=";
    public static String Yangtzeu_Search_Subject = "http://calis.yangtzeu.edu.cn:8000/opac/search?searchWay=subject&q=";

    /**
     * 校历图片
     */
    public static String Yangtzeu_School_1 = "http://m.xyll520.top/newyangtzeu/app_xiaoli/school1.png";
    public static String Yangtzeu_School_2 = "http://m.xyll520.top/newyangtzeu/app_xiaoli/school3.png";
    public static String Yangtzeu_School_3 = "http://m.xyll520.top/newyangtzeu/app_xiaoli/school2.png";


    public static String Yangtzeu_CET_Music = "https://mp.weixin.qq.com/mp/homepage?__biz=MzUxMjkxMTAzMQ==&hid=2&sn=a37b8df5890222d5ee1aa10bcc69adb8&scene=18&devicetype=android-22&version=26060736&lang=zh_CN&nettype=WIFI&ascene=7&session_us=gh_a02dab1c8a16";
    public static String Yangtzeu_CET6_Music = "http://mp.weixin.qq.com/mp/homepage?__biz=MzI3MTAwOTkzOA==&hid=8&sn=c0ce07bdc454a6200b8d9c746a438424&scene=18#wechat_redirect";
    public static String Yangtzeu_CET_Test = "http://mp.weixin.qq.com/mp/homepage?__biz=MzU1NjA5NjI3MA==&hid=20&sn=0643d4cd9698883e99056563444d91d1&scene=18#wechat_redirect";
    public static String Yangtzeu_CET_GanHuo = "http://mp.weixin.qq.com/mp/homepage?__biz=MzU1NjA5NjI3MA==&hid=21&sn=fe475e214283db2706e6b9c7c557dac9&scene=18#wechat_redirect";


    /**
     * 杂项
     */
    //H5游戏
    public static String Yangtzeu_Game_Url = "http://h5.qq.com/";
    //中国图书
    public static String Yangtzeu_Search_Book = "http://m.ndlib.cn/03/html/searchresult.html?type=0&search=";
    //百度文库
    public static String Yangtzeu_Search_Office = "https://wenku.baidu.com/search?word=";
    //图片搜索
    public static String Yangtzeu_Search_Image = "http://m.image.haosou.com/i?q=";
    //音乐搜索
    public static String Yangtzeu_Search_Music = "http://music.baidu.com/search/";
    //百度爆笑
    public static String Yangtzeu_Search_Joke = "https://m.baidu.com/sf?pd=joke&openapi=1&dspName=iphone&from_sf=1&tn=tangram&resource_id=4761&query=%E7%AC%91%E8%AF%9D&category=%E8%A7%86%E9%A2%91";
    //网页搜索
    public static String Yangtzeu_Search_Web = "https://www.zhihu.com/search?type=content&q=";
    //成语查询
    public static String Yangtzeu_ChengYv = "http://apicloud.mob.com/appstore/idiom/query?key=" + key + "&name=";
    //词语查询
    public static String Yangtzeu_CiYv = "http://apicloud.mob.com/appstore/dictionary/query?key=" + key + "&name=";
    //天气查询
    public static String Yangtzeu_Weather = "http://apicloud.mob.com/v1/weather/query?key=" + key + "&province=湖北&city=";

    //每日一句
    public static String Yangtzeu_Day_Trip = "http://open.iciba.com/dsapi/";
    //每日一句
    public static String Yangtzeu_My_Day_Trip = "http://m.xyll520.top/newyangtzeu/app_json/MyDayTrip.json";
    //每日一句
    public static String Yangtzeu_Which_Day_Trip = "http://m.xyll520.top/newyangtzeu/app_json/WhichDayTrip.json";
    //最近节日
    public static final String Yangtzeu_Next_Holiday = "http://timor.tech/api/holiday/tts/next";

    //元素周期表
    public static String Yangtzeu_Chem = "http://m.xyll520.top/newyangtzeu/app_chm/index.html";

    //失物招领
    public static String Yangtzeu_Things_FaBu = "http://m.xyll520.top/newyangtzeu/app_php/things.php";
    //失物招领
    public static String Yangtzeu_Things_Show = "http://m.xyll520.top/newyangtzeu/app_php/showthings.php";
    //失物招领 搜索
    public static String Yangtzeu_Things_Search = "http://m.xyll520.top/newyangtzeu/app_php/searchthing.php";
    //删除物品
    public static String Yangtzeu_RemoveThing = "http://m.xyll520.top/newyangtzeu/app_php/rmthing.php";



    public static String Yangtzeu_Physical_Home = "http://phylab.yangtzeu.edu.cn/jpkc/";
    /**
     * "password\t12345678\n"+
     * "Submit\t立即登陆\n"+
     * "userid\t201703246\n"+
     * "usertype\tstudent"
     */


    public static String Yangtzeu_Physical_Login = "http://10.10.16.16/index.php/Home/Index/login";
    /**
     * "expchoice\t10019\n"+
     * "expclass\t0\n"+
     * "expday\t0"
     */
    public static String Yangtzeu_Physical_List = "http://10.10.16.16/index.php/Home/Student/listexp";
    /**
     * "del_id[]\t1000103259956\n"+
     * "Submit\t删除预约"
     */
    public static String Yangtzeu_Physical_Delete = "http://10.10.16.16/index.php/Home/Student/delmyexp";
    //我的预约
    public static String Yangtzeu_Physical_Grade = "http://10.10.16.16/index.php/Home/Student/listmyexp";
    //我的预约
    public static String Yangtzeu_Physical_Add = "http://10.10.16.16/index.php/Home/Student/prelistexp";


    /**
     * 七牛云图片
     */
    public static String DefeatName = "whysroom";
    public static String DefeatAK = "m_xUqlJMur8sdyH7VCO_Fxkv57qCHBWZnwfAVNoW";
    public static String DefeatSK = "48_CSjZ2nP-gu_pi3-JNNOs42m-GlyaWoX1AA9WY";
    public static String DefeatUrl = "http://p04pfl7p6.bkt.clouddn.com/";

}
