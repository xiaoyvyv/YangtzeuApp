package com.yangtzeu.ui.view;


import android.support.design.widget.TabLayout;
import android.support.v4.view.ViewPager;

import com.yangtzeu.ui.adapter.FragmentAdapter;

public interface GradeView {

    FragmentAdapter getAdapter();
    ViewPager getViewPager();

    TabLayout getTabLayout();
}
