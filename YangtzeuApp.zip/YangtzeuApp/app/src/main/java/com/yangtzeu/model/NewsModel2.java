package com.yangtzeu.model;

import android.app.Activity;
import android.util.Log;

import com.blankj.utilcode.util.LogUtils;
import com.yangtzeu.entity.NewsBean;
import com.yangtzeu.http.OkHttp;
import com.yangtzeu.http.OnResultStringListener;
import com.yangtzeu.model.imodel.INewsModel2;
import com.yangtzeu.ui.view.NewsView2;
import com.yangtzeu.url.Url;

import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.select.Elements;

public class NewsModel2 implements INewsModel2 {


    @Override
    public void loadNewsData(Activity activity, final NewsView2 view) {
        String news_param = view.getUrlParam();
        String news_url = getNewsUrl(news_param, view.getPage());

        final int old_index = view.getNewsAdapter().getItemCount();
        OkHttp.do_Get(news_url, new OnResultStringListener() {
            @Override
            public void onResponse(String response) {
                view.getSmartRefreshLayout().finishLoadMore();
                view.getSmartRefreshLayout().finishRefresh();

                try {
                    Document document = Jsoup.parse(response);
                    Elements content_list = document.select("div.content_c#content_list ul");
                    Elements li = content_list.get(0).select("ul li");
                    for (int i = 0; i < li.size(); i++) {
                        String title = li.get(i).select("li a").text();
                        String url = Url.Yangtzeu_News_Header + li.get(i).select("li a").attr("href");
                        String time = li.get(i).select("li span").text();

                        NewsBean bean = new NewsBean();
                        bean.setTilte(title);
                        bean.setKind(view.getKind());
                        bean.setUrl(url);
                        bean.setTime(time);
                        view.getData().add(bean);
                    }
                    view.getNewsAdapter().setDate(view.getData());
                    view.getNewsAdapter().notifyItemRangeChanged(old_index, view.getNewsAdapter().getItemCount());
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }

            @Override
            public void onFailure(String error) {
                view.getSmartRefreshLayout().finishLoadMore();
                view.getSmartRefreshLayout().finishRefresh();
                LogUtils.e(error);
            }
        });

    }


    private String getNewsUrl(String param, int page) {
        String url;
        if (param.contains("list")) {
            url = Url.Yangtzeu_News_Header + param + page + ".html";
        } else {
            url = Url.Yangtzeu_News_Header + param;
        }
        return url;
    }
}
