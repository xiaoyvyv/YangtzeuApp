package com.yangtzeu.ui.view;

import android.view.View;

import cn.bingoogolapple.bgabanner.BGABanner;

public interface HomePartView1 {
    View getRootView();
}
