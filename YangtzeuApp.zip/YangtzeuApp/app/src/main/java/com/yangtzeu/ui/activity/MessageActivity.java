package com.yangtzeu.ui.activity;

import android.os.Bundle;
import android.support.v7.widget.RecyclerView;
import android.support.v7.widget.Toolbar;

import com.scwang.smartrefresh.layout.SmartRefreshLayout;
import com.scwang.smartrefresh.layout.api.RefreshLayout;
import com.scwang.smartrefresh.layout.listener.OnRefreshListener;
import com.yangtzeu.R;
import com.yangtzeu.entity.MessageBean;
import com.yangtzeu.presenter.MessagePresident;
import com.yangtzeu.ui.activity.base.BaseActivity;
import com.yangtzeu.ui.adapter.MessageAdapter;
import com.yangtzeu.ui.view.MessageView;
import com.yangtzeu.utils.MyUtils;


public class MessageActivity extends BaseActivity implements MessageView {

    private MessageBean data;
    private Toolbar toolbar;
    private MessageAdapter adapter;
    private RecyclerView mRecyclerView;
    private SmartRefreshLayout refresh;
    private MessagePresident president;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        data = (MessageBean) getIntent().getSerializableExtra("data");

        setContentView(R.layout.activity_message);
        super.onCreate(savedInstanceState);
        MyUtils.setToolbarBackToHome(this, toolbar);
    }

    @Override
    public void findViews() {
        toolbar = findViewById(R.id.toolbar);
        mRecyclerView = findViewById(R.id.mRecyclerView);
        refresh = findViewById(R.id.refresh);

    }

    @Override
    public void setEvents() {
        president = new MessagePresident(this, this);
        adapter = new MessageAdapter(this);
        mRecyclerView.setAdapter(adapter);

        refresh.setEnableLoadMore(false);
        refresh.setOnRefreshListener(new OnRefreshListener() {
            @Override
            public void onRefresh(RefreshLayout refreshLayout) {
                president.loadMessageData();
            }
        });
        refresh.autoRefresh();
    }


    @Override
    public RecyclerView getRecyclerView() {
        return mRecyclerView;
    }

    @Override
    public MessageBean getMessageData() {
        return data;
    }

    @Override
    public MessageAdapter getAdapter() {
        return adapter;
    }

    @Override
    public SmartRefreshLayout getRefresh() {
        return refresh;
    }
}
