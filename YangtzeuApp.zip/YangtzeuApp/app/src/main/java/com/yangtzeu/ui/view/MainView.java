package com.yangtzeu.ui.view;

import android.support.design.widget.BottomNavigationView;
import android.support.v4.app.Fragment;
import android.support.v4.widget.DrawerLayout;
import android.widget.FrameLayout;

import com.yangtzeu.ui.fragment.GradeFragment;
import com.yangtzeu.ui.fragment.HomeFragment;
import com.yangtzeu.ui.fragment.MineFragment;
import com.yangtzeu.ui.fragment.TableFragment;

public interface MainView {
    FrameLayout getFragmentContainer();
    HomeFragment getHomeFragment();
    TableFragment getTableFragment();

    MineFragment getMineFragment();
    DrawerLayout getDrawerLayout();
    BottomNavigationView getBottomNavigationView();

    GradeFragment getGradeFragment();
}
