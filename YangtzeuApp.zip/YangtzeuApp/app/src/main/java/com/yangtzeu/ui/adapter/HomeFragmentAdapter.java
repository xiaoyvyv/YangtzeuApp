package com.yangtzeu.ui.adapter;

/**
 * Created by Administrator on 2018/1/30.
 *
 */

import android.annotation.SuppressLint;
import android.content.Context;
import android.support.annotation.NonNull;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import com.blankj.utilcode.util.ConvertUtils;
import com.blankj.utilcode.util.TimeUtils;
import com.yangtzeu.R;


public class HomeFragmentAdapter extends RecyclerView.Adapter<HomeFragmentAdapter.ViewHolder> {
    private String title[] = {
            "双十一","元旦节", "18年寒假", "19年开学", "清明节",
            "劳动节", "端午节","19年暑假"};
    private String date[] = {
            "2018-11-11","2019-01-01", "2019-01-21", "2019-02-25", "2019-04-05",
            "2019-05-01", "2019-06-07","2019-07-15"};

    private Context context;

    public HomeFragmentAdapter(Context context) {
        this.context = context;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup view, int viewType) {
        return new ViewHolder(LayoutInflater.from(context).inflate(R.layout.fragment_home_item, view, false));
    }

    @SuppressLint("SetTextI18n")
    @Override
    public void onBindViewHolder(@NonNull final ViewHolder viewHolder, @SuppressLint("RecyclerView") final int i) {
        String data = date[i] + " 08:00:00";
        String fitTimeSpan = ConvertUtils.millis2FitTimeSpan(TimeUtils.string2Millis(data)-TimeUtils.getNowMills(), 1);
        viewHolder.title.setText(title[i] + ":" + fitTimeSpan);
    }

    @Override
    public long getItemId(int i) {
        return 0;
    }

    @Override
    public int getItemCount() {
        return title.length;
    }

    @Override
    public int getItemViewType(int position) {
        return super.getItemViewType(position);
    }

    class ViewHolder extends RecyclerView.ViewHolder {
        TextView title;
        ViewHolder(View view) {
            super(view);
            title = view.findViewById(R.id.title);
        }
    }

}