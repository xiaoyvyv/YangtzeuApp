package com.yangtzeu.entity;

public class HolidayNextBean {

    /**
     * code : 0
     * tts : 最近的一个节日是2018-12-30的元旦，还有84天。在元旦之前先要调休。
     */

    private int code;
    private String tts;

    public int getCode() {
        return code;
    }

    public void setCode(int code) {
        this.code = code;
    }

    public String getTts() {
        return tts;
    }

    public void setTts(String tts) {
        this.tts = tts;
    }
}
