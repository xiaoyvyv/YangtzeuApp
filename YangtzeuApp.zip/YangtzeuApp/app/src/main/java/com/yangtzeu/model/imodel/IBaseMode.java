package com.yangtzeu.model.imodel;

public  interface IBaseMode {
    void findViews();
    void setEvents();
}
