package com.yangtzeu.ui.view;

import android.support.v7.widget.RecyclerView;

import com.scwang.smartrefresh.layout.SmartRefreshLayout;
import com.yangtzeu.entity.MessageBean;
import com.yangtzeu.ui.adapter.MessageAdapter;

public interface MessageView {
    RecyclerView getRecyclerView();

    MessageBean getMessageData();

    MessageAdapter getAdapter();

    SmartRefreshLayout getRefresh();
}
