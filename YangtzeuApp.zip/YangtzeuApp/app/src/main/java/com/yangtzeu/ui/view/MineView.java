package com.yangtzeu.ui.view;

import android.support.v7.widget.Toolbar;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.scwang.smartrefresh.layout.SmartRefreshLayout;

import de.hdodenhof.circleimageview.CircleImageView;

public interface MineView {
    ImageView getHeader();

    TextView getClassView();

    TextView getNameView();

    Toolbar getToolbar();

    TextView getUserNumberView();

    TextView getEmailView();

    TextView getMessageView();

    LinearLayout getMessageLayout();

    TextView getMessageImage();

    SmartRefreshLayout getRefresh();
}
