package com.yangtzeu.model;

import android.app.Activity;

import com.blankj.utilcode.util.LogUtils;
import com.blankj.utilcode.util.ObjectUtils;
import com.blankj.utilcode.util.SPUtils;
import com.blankj.utilcode.util.ToastUtils;
import com.yangtzeu.entity.MessageBean;
import com.yangtzeu.model.imodel.IMessageModel;
import com.yangtzeu.ui.view.MessageView;

import java.util.ArrayList;
import java.util.List;

public class MessageModel implements IMessageModel {
    @Override
    public void loadMessageData(Activity activity, MessageView view) {
        final MessageBean bean = view.getMessageData();
        String info = bean.getInfo();
        if (info.contains("查询成功")) {
            if (ObjectUtils.isNotEmpty(bean.getData())) {
                final String number = SPUtils.getInstance("user_info").getString("number");
                final List<MessageBean.DataBean> all_data = bean.getData();
                final List<MessageBean.DataBean> my_data = new ArrayList<>();
                for (int i = 0; i < all_data.size(); i++) {
                    String to = all_data.get(i).getTo();
                    //只过滤当前用户的消息
                    if (to.contains(number) || to.contains("yangtzeu")) {
                        my_data.add(all_data.get(i));
                    }
                }
                view.getAdapter().setData(my_data);
                view.getAdapter().notifyItemRangeChanged(0,view.getAdapter().getItemCount());
            } else {
                LogUtils.e("信息暂无数据");
            }
        } else {
            ToastUtils.showShort(info);
        }
        view.getRefresh().finishRefresh();

    }
}
