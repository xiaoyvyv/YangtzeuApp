package com.yangtzeu.model;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.Intent;
import android.support.design.widget.TabLayout;
import android.support.v4.view.ViewPager;
import android.view.KeyEvent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import com.blankj.utilcode.util.KeyboardUtils;
import com.blankj.utilcode.util.ObjectUtils;
import com.blankj.utilcode.util.ToastUtils;
import com.yangtzeu.R;
import com.yangtzeu.database.DatabaseUtils;
import com.yangtzeu.entity.BannerBean;
import com.yangtzeu.model.imodel.INewsModel1;
import com.yangtzeu.ui.activity.WebActivity;
import com.yangtzeu.ui.fragment.HomePartFragment2;
import com.yangtzeu.ui.view.NewsView1;
import com.yangtzeu.url.Url;
import com.yangtzeu.utils.MyUtils;
import com.yangtzeu.utils.YangtzeuUtils;

import java.io.UnsupportedEncodingException;
import java.net.URLEncoder;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

import cn.bingoogolapple.bgabanner.BGABanner;

public class NewsModel1 implements INewsModel1 {

    @Override
    public void loadBanner(final Activity activity, NewsView1 view) {
        //加载内存的Banner
        List<String> title = new ArrayList<>();
        final List<String> url = new ArrayList<>();
        List<String> image = new ArrayList<>();
        List<BannerBean> list = DatabaseUtils.getHelper(activity, "banner.db").queryAll(BannerBean.class);
        if (ObjectUtils.isNotEmpty(list)) {
            for (int i = 0; i < list.size(); i++) {
                title.add(list.get(i).getTitle());
                url.add(list.get(i).getUrl());
                image.add(list.get(i).getImage());
            }
            view.getBGABanner().setData(image, title);
            view.getBGABanner().setAdapter(new BGABanner.Adapter<ImageView, String>() {
                @Override
                public void fillBannerItem(BGABanner banner, ImageView itemView, String model, int position) {
                    itemView.setScaleType(ImageView.ScaleType.FIT_XY);
                    MyUtils.loadImage(activity, itemView, model);
                }
            });
            view.getBGABanner().setDelegate(new BGABanner.Delegate() {
                @Override
                public void onBannerItemClick(BGABanner banner, View itemView, Object model, int position) {
                    MyUtils.openUrl(activity, url.get(position));
                }
            });
        }
        //获取最新的Banner
        YangtzeuUtils.getBanner(activity);

    }

    @Override
    public void fitGridView(final Activity activity, final NewsView1 view) {
        view.getSearchView().setOnKeyListener(new View.OnKeyListener() {
            @Override
            public boolean onKey(View v, int keyCode, KeyEvent event) {
                // 修改回车键功能
                if (keyCode == KeyEvent.KEYCODE_ENTER && event.getAction() == KeyEvent.ACTION_DOWN) {
                    // 先隐藏键盘
                    KeyboardUtils.hideSoftInput(view.getSearchView());
                    String input = view.getSearchView().getText().toString().trim();
                    if (!input.isEmpty()) {
                        String de_input = input;
                        try {
                            de_input = URLEncoder.encode(input, "gb2312");
                        } catch (UnsupportedEncodingException e) {
                            e.printStackTrace();
                        }
                        view.getSearchView().setText(null);
                        MyUtils.startActivity(new Intent(activity, WebActivity.class).putExtra("from_url", Url.Yangtzeu_News_Search + de_input));

                    } else ToastUtils.showShort(R.string.please_input);
                }
                return false;
            }
        });

        view.getGridView().setNumColumns(3);
        view.getGridView().setVerticalSpacing(30);
        view.getGridView().setAdapter(new BaseAdapter() {
            @Override
            public int getCount() {
                return view.getTitleArray().length;
            }

            @Override
            public Object getItem(int position) {
                return view.getTitleArray()[position];
            }

            @Override
            public long getItemId(int position) {
                return position;
            }

            @SuppressLint("InflateParams")
            @Override
            public View getView(final int position, View convertView, ViewGroup parent) {
                final ViewHolder viewHolder;
                if (convertView == null) {
                    viewHolder = new ViewHolder();
                    LayoutInflater inflater = LayoutInflater.from(activity);
                    convertView = inflater.inflate(R.layout.fragment_news_layout1_item, null);
                    viewHolder.title = convertView.findViewById(R.id.Title);
                    convertView.setTag(viewHolder);
                } else {
                    viewHolder = (ViewHolder) convertView.getTag();
                }
                viewHolder.title.setText(view.getTitleArray()[position]);
                viewHolder.title.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        ViewPager viewPager = HomePartFragment2.mViewPager;
                        if (viewPager != null) {
                            viewPager.setCurrentItem(position + 1);
                        }
                        TabLayout tabLayout = HomePartFragment2.tabLayout;
                        if (tabLayout != null) {
                            Objects.requireNonNull(tabLayout.getTabAt(position + 1)).select();
                        }
                    }
                });

                return convertView;
            }

            class ViewHolder {
                TextView title;
            }
        });

    }

}
