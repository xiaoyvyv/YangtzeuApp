package com.yangtzeu.ui.activity;

import android.app.AlertDialog;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.design.widget.TextInputEditText;
import android.text.Html;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import com.blankj.utilcode.util.ToastUtils;
import com.yangtzeu.R;
import com.yangtzeu.presenter.LoginPresenter;
import com.yangtzeu.ui.activity.base.BaseActivity;
import com.yangtzeu.ui.view.LoginView;
import com.yangtzeu.url.Url;
import com.yangtzeu.utils.MyUtils;

public class LoginActivity extends BaseActivity implements LoginView {
    private Button loginButton;
    private TextInputEditText passwordView;
    private TextInputEditText numberView;
    private TextView belong;


    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        setContentView(R.layout.activity_login);
        super.onCreate(savedInstanceState);
    }

    @Override
    public void findViews() {
        loginButton = findViewById(R.id.loginButton);
        passwordView = findViewById(R.id.passwordView);
        numberView = findViewById(R.id.numberView);
        belong = findViewById(R.id.belong);
    }

    @Override
    public void setEvents() {
        LoginPresenter presenter = new LoginPresenter(this, this);
        presenter.loadLoginEvent();

        belong.setText(Html.fromHtml(getString(R.string.belong_xy)));
    }

    @Override
    public TextInputEditText getNumberView() {
        return numberView;
    }

    @Override
    public TextInputEditText getPassWordView() {
        return passwordView;
    }

    @Override
    public Button getLoginButton() {
        return loginButton;
    }

    public void onClick(View view) {
        switch (view.getId()) {
            case R.id.yangtzeu_web:
                MyUtils.openUrl(this, Url.Yangtzeu_Base_Url);
                break;
            case R.id.forget_pass:
                ToastUtils.showShort(R.string.deal_forget_pass);
                break;
            case R.id.belong:
                AlertDialog dialog = new AlertDialog.Builder(LoginActivity.this)
                        .setTitle(R.string.app_rule)
                        .setMessage(getString(R.string.app_rule_text1) +
                                getString(R.string.app_rule_text2))
                        .setPositiveButton(R.string.know, null)
                        .create();
                dialog.show();
                dialog.setCanceledOnTouchOutside(false);
                dialog.setCancelable(false);
                break;
        }


    }
}
