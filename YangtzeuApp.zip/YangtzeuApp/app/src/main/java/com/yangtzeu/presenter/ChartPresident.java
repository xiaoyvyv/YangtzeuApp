package com.yangtzeu.presenter;

import android.app.Activity;

import com.yangtzeu.model.ChartModel;
import com.yangtzeu.ui.view.ChartView;
public class ChartPresident {
    private Activity activity;
    private ChartView view;
    private ChartModel mode;

    public ChartPresident(Activity activity, ChartView view) {
        this.activity = activity;
        this.view = view;
        mode = new ChartModel();
    }

    public void setChart() {
        mode.setChart(activity, view);
    }

    public void setColumnChart() {
        mode.setColumnChart(activity, view);
    }
}
