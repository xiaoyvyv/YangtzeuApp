package com.yangtzeu.model.imodel;

import android.app.Activity;

import com.yangtzeu.ui.view.ChartView;

public interface IChartModel {
    void setChart(Activity activity, ChartView view);

    void setColumnChart(Activity activity, ChartView view);
}
