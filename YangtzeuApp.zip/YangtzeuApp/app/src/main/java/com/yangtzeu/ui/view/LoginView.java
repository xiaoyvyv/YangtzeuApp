package com.yangtzeu.ui.view;

import android.support.design.widget.TextInputEditText;
import android.widget.Button;

public interface LoginView {
    TextInputEditText getNumberView();
    TextInputEditText getPassWordView();
    Button getLoginButton();
}
