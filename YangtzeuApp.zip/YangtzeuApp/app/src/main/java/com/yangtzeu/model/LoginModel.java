package com.yangtzeu.model;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.view.View;

import com.blankj.utilcode.util.ActivityUtils;
import com.blankj.utilcode.util.KeyboardUtils;
import com.blankj.utilcode.util.SPUtils;
import com.blankj.utilcode.util.ToastUtils;
import com.yangtzeu.R;
import com.yangtzeu.model.imodel.ILoginModel;
import com.yangtzeu.ui.activity.MainActivity;
import com.yangtzeu.ui.view.LoginView;
import com.yangtzeu.url.Url;
import com.yangtzeu.utils.MyUtils;
import com.yangtzeu.utils.UserUtils;

import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.select.Elements;

import java.util.Objects;

public class LoginModel implements ILoginModel {

    @Override
    public void loadLoginEvent(final Activity activity, final LoginView view) {
        String number = SPUtils.getInstance("user_info").getString("number");
        String password = SPUtils.getInstance("user_info").getString("password");
        view.getNumberView().setText(number);
        view.getPassWordView().setText(password);

        view.getLoginButton().setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String user_number = Objects.requireNonNull(view.getNumberView().getText()).toString().trim();
                String user_password = Objects.requireNonNull(view.getPassWordView().getText()).toString().trim();
                if (user_number.isEmpty()) {
                    ToastUtils.showShort(R.string.input_number);
                    return;
                }
                if (user_password.isEmpty()) {
                    ToastUtils.showShort(R.string.input_pass);
                    return;
                }

                KeyboardUtils.hideSoftInput(view.getPassWordView());

                SPUtils.getInstance("user_info").put("number", user_number);
                SPUtils.getInstance("user_info").put("password", user_password);

                ToastUtils.showLong(R.string.login_ing);

                String UserInfo[] = {user_number, user_password};
                UserUtils.do_Login(activity, UserInfo, new UserUtils.OnLogResultListener() {
                    @Override
                    public void onSuccess(String result) {
                        loginSuccess(activity, view, result);
                    }

                    @Override
                    public void onFailure(String error) {
                        loginFailure(activity, view,error);
                    }
                });

            }
        });


    }

    private void loginFailure(final Activity activity, LoginView view, String error) {
        ToastUtils.showShort(error);
        view.getLoginButton().setText(R.string.login_again);
        view.getLoginButton().setEnabled(true);
        SPUtils.getInstance("user_info").put("online", false);
        if (error.contains("教务处网络过载")) {
            AlertDialog dialog = new AlertDialog.Builder(activity)
                    .setTitle(R.string.trip)
                    .setMessage(R.string.can_login_please_open_web)
                    .setPositiveButton(R.string.know,null)
                    .setNegativeButton(R.string.try_to_open, new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialog, int which) {
                            MyUtils.openBrowser(activity, Url.Yangtzeu_Login_Path);
                        }
                    })
                    .create();
            dialog.setCanceledOnTouchOutside(false);
            dialog.show();
        }

    }

    private void loginSuccess(Activity activity, LoginView view, String result) {
        ToastUtils.showShort(R.string.login_success);
        Document document = Jsoup.parse(result);
        Elements form = document.select("form");
        String id = form.text();
        id = id.replace(" ", "\n\n");
        SPUtils.getInstance("user_info").put("online", true);
        view.getLoginButton().setText(R.string.login_success);
        view.getLoginButton().setEnabled(false);
        AlertDialog dialog = new AlertDialog.Builder(activity)
                .setTitle(R.string.welcome)
                .setMessage(activity.getString(R.string.your_id) + "：" + id)
                .setPositiveButton(R.string.know, new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        dialog.dismiss();
                        ActivityUtils.finishAllActivities();
                        MyUtils.startActivity(MainActivity.class);
                    }
                })
                .create();
        dialog.setCanceledOnTouchOutside(false);
        dialog.show();
        dialog.setCancelable(false);
    }
}
