package com.yangtzeu.model.imodel;

import android.app.Activity;

import com.yangtzeu.ui.view.HomePartView2;
import com.yangtzeu.ui.view.HomePartView3;

public interface IHomePart3Model {

    void loadView(Activity activity, HomePartView3 view);
}
