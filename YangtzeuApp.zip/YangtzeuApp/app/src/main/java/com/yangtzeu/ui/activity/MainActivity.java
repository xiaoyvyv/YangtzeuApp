package com.yangtzeu.ui.activity;

import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.support.annotation.NonNull;
import android.support.design.widget.BottomNavigationView;
import android.support.design.widget.NavigationView;
import android.support.design.widget.TabLayout;
import android.support.v4.view.GravityCompat;
import android.support.v4.widget.DrawerLayout;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.FrameLayout;

import com.blankj.utilcode.util.ActivityUtils;
import com.blankj.utilcode.util.AppUtils;
import com.blankj.utilcode.util.ToastUtils;
import com.lib.x5web.X5WebView;
import com.yangtzeu.R;
import com.yangtzeu.presenter.MainPresenter;
import com.yangtzeu.service.YangtzeuService;
import com.yangtzeu.ui.activity.base.BaseActivity;
import com.yangtzeu.ui.fragment.GradeFragment;
import com.yangtzeu.ui.fragment.HomeFragment;
import com.yangtzeu.ui.fragment.HomePartFragment3;
import com.yangtzeu.ui.fragment.MineFragment;
import com.yangtzeu.ui.fragment.TableFragment;
import com.yangtzeu.ui.view.MainView;
import com.yangtzeu.utils.UserUtils;
import com.yangtzeu.utils.YangtzeuUtils;

import java.util.Objects;

public class MainActivity extends BaseActivity
        implements NavigationView.OnNavigationItemSelectedListener, MainView {

    private DrawerLayout drawer;
    private NavigationView leftNavigationView;
    private BottomNavigationView bottomNavigationView;
    private FrameLayout container;
    private HomeFragment homeFragment;
    private Intent intent;
    private TableFragment tableFragment;
    private MineFragment mineFragment;
    private GradeFragment gradeFragment;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        setContentView(R.layout.activity_main);
        super.onCreate(savedInstanceState);
    }


    @Override
    public void findViews() {
        leftNavigationView = findViewById(R.id.nav_view);
        drawer = findViewById(R.id.drawer_layout);
        bottomNavigationView = findViewById(R.id.bottomNavigationView);
        container = findViewById(R.id.container);
    }

    @Override
    public void setEvents() {
        intent = new Intent(MainActivity.this, YangtzeuService.class);
        startService(intent);

        leftNavigationView.setNavigationItemSelectedListener(this);


        homeFragment = new HomeFragment();
        homeFragment.setUserVisibleHint(true);

        gradeFragment= new GradeFragment();

        tableFragment = new TableFragment();

        mineFragment = new MineFragment();


        MainPresenter presenter = new MainPresenter(this, this);
        presenter.setBottomViewWithFragment();

        YangtzeuUtils.getAlertNotice(this);
        YangtzeuUtils.checkAppVersion(this);
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.main, menu);
        return true;
    }


    //标题栏菜单点击事件
    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case R.id.search:


                break;
            case R.id.download:


                break;
        }
        return super.onOptionsItemSelected(item);
    }

    //侧滑抽屉菜单点击事件
    @Override
    public boolean onNavigationItemSelected(@NonNull MenuItem item) {
        switch (item.getItemId()) {
            case R.id.setting_center:

                break;
            case R.id.change_theme:
                UserUtils.do_Logout(this);
                break;
        }
        drawer.closeDrawer(GravityCompat.START);
        return true;
    }

    @Override
    public void onBackPressed() {
        TabLayout.Tab item0 = Objects.requireNonNull(HomeFragment.tabLayout.getTabAt(0));
        TabLayout.Tab item2 = Objects.requireNonNull(HomeFragment.tabLayout.getTabAt(2));
        X5WebView web = HomePartFragment3.webView;
        MenuItem view1 = bottomNavigationView.getMenu().getItem(0);

        if (drawer.isDrawerOpen(GravityCompat.START)) {
            drawer.closeDrawer(GravityCompat.START);
        } else if (!view1.isChecked()) {
            bottomNavigationView.setSelectedItemId(view1.getItemId());
        } else if (web != null && web.canGoBack()) {
            web.goBack();
            if (!item2.isSelected()) {
                item2.select();
            }
        } else if (item0 != null && !item0.isSelected()) {
            item0.select();
        } else {
            exit();
        }

    }


    private boolean isExit = false;

    private void exit() {
        if (!isExit) {
            isExit = true;
            ToastUtils.showShort(getString(R.string.double_exit));
            new Handler(getMainLooper()) {
                @Override
                public void handleMessage(Message msg) {
                    super.handleMessage(msg);
                    isExit = false;
                }
            }.sendEmptyMessageDelayed(0, 2000); // 利用handler延迟发送更改状态信息
        } else {
            UserUtils.do_Logout_Simple(this, new UserUtils.OnLogResultListener() {
                @Override
                public void onSuccess(String response) {
                    ActivityUtils.finishAllActivities();
                    AppUtils.exitApp();
                }

                @Override
                public void onFailure(String error) {
                    ActivityUtils.finishAllActivities();
                    AppUtils.exitApp();

                }
            });

        }
    }

    @Override
    public FrameLayout getFragmentContainer() {
        return container;
    }


    @Override
    public HomeFragment getHomeFragment() {
        return homeFragment;
    }

    @Override
    public GradeFragment getGradeFragment() {
        return gradeFragment;
    }

    @Override
    public TableFragment getTableFragment() {
        return tableFragment;
    }

    @Override
    public MineFragment getMineFragment() {
        return mineFragment;
    }

    @Override
    public DrawerLayout getDrawerLayout() {
        return drawer;
    }


    @Override
    public BottomNavigationView getBottomNavigationView() {
        return bottomNavigationView;
    }

    @Override
    protected void onDestroy() {
        if (intent != null) {
            stopService(intent);
        }
        super.onDestroy();
    }


    public void exit(View view) {
        AlertDialog dialog = new AlertDialog.Builder(MainActivity.this)
                .setTitle(R.string.trip)
                .setMessage(R.string.is_logout)
                .setPositiveButton(R.string.done, new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        UserUtils.do_Logout(MainActivity.this);
                    }
                })
                .setNegativeButton(R.string.clear, null)
                .create();
        dialog.show();
    }
}
