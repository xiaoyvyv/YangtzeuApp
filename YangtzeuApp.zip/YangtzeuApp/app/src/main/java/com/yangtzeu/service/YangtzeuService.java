package com.yangtzeu.service;

import android.app.Service;
import android.content.Intent;
import android.os.IBinder;
import android.support.annotation.Nullable;

import com.blankj.utilcode.util.LogUtils;
import com.blankj.utilcode.util.SPUtils;
import com.yangtzeu.utils.YangtzeuUtils;

import java.util.Timer;
import java.util.TimerTask;

/**
 * Created by Administrator on 2018/3/3.
 *
 */

public class YangtzeuService extends Service {
    private TimerTask timeTask;
    private Timer timer;

    @Nullable
    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }

    @Override
    public void onCreate() {
        super.onCreate();
        timer = new Timer();
        timeTask = new TimerTask() {
            @Override
            public void run() {
                boolean isOnline = SPUtils.getInstance("user_info").getBoolean("online", false);
                if (isOnline) {
                    YangtzeuUtils.getStudentInfo();
                    LogUtils.i("保持服务器连接");
                }
            }
        };
        timer.schedule(timeTask, 0, 30000);
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        return super.onStartCommand(intent, flags, startId);
    }

    @Override
    public void onDestroy() {
        if (timer != null) {
            timer.cancel();
        }
        if (timeTask != null) {
            timeTask.cancel();
        }
        super.onDestroy();
    }
}
