package com.yangtzeu.ui.view;

import android.support.design.widget.AppBarLayout;
import android.support.design.widget.TabLayout;
import android.support.v4.view.ViewPager;
import android.support.v4.widget.DrawerLayout;
import android.support.v7.widget.Toolbar;
import android.widget.TextView;

public interface HomeView {
    Toolbar getToolbar();

    DrawerLayout getDrawerLayout();

    ViewPager getViewPager();

    TabLayout getTabLayout();

    AppBarLayout getAppBarLayout();

    TextView getHoliday();

    TextView getTemp();

    TextView getWeather();

    TextView getCity();

    TextView getWeek();

    TextView getPass();

    TextView getStudyTime();

}
