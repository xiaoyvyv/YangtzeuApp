package com.yangtzeu.ui.view;

import android.support.design.widget.TabLayout;
import android.support.v4.view.ViewPager;


public interface HomePartView2 {

    TabLayout getTabLayout();

    ViewPager getViewPager()
            ;
}
