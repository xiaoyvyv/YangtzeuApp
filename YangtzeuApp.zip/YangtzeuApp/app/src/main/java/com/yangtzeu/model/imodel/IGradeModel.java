package com.yangtzeu.model.imodel;

import android.app.Activity;

import com.yangtzeu.ui.view.GradeView;

public interface IGradeModel {
    void setViewPager(Activity activity, GradeView view);
}
