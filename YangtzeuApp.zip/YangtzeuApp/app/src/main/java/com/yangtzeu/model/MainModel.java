package com.yangtzeu.model;

import android.app.Activity;
import android.support.annotation.NonNull;
import android.support.design.bottomnavigation.LabelVisibilityMode;
import android.support.design.widget.BottomNavigationView;
import android.support.design.widget.TabLayout;
import android.support.v4.app.FragmentManager;
import android.support.v7.app.AppCompatActivity;
import android.view.MenuItem;

import com.blankj.utilcode.util.FragmentUtils;
import com.yangtzeu.R;
import com.yangtzeu.model.imodel.IMainModel;
import com.yangtzeu.ui.fragment.HomeFragment;
import com.yangtzeu.ui.view.MainView;

import java.util.Objects;

public class MainModel implements IMainModel {
    @Override
    public void setBottomViewWithFragment(Activity activity, final MainView view) {
        final FragmentManager manager = ((AppCompatActivity) activity).getSupportFragmentManager();
        FragmentUtils.add(manager, view.getHomeFragment(), view.getFragmentContainer().getId(), false);
        FragmentUtils.add(manager, view.getTableFragment(), view.getFragmentContainer().getId(), true);
        FragmentUtils.add(manager, view.getMineFragment(), view.getFragmentContainer().getId(), true);
        FragmentUtils.add(manager, view.getGradeFragment(), view.getFragmentContainer().getId(), true);

        view.getBottomNavigationView().setLabelVisibilityMode(LabelVisibilityMode.LABEL_VISIBILITY_LABELED);
        view.getBottomNavigationView().setOnNavigationItemSelectedListener(new BottomNavigationView.OnNavigationItemSelectedListener() {
            @Override
            public boolean onNavigationItemSelected(@NonNull MenuItem menuItem) {
                switch (menuItem.getItemId()) {
                    case R.id.home:
                        FragmentUtils.showHide(view.getHomeFragment(), view.getGradeFragment(), view.getTableFragment(), view.getMineFragment());
                        view.getHomeFragment().setUserVisibleHint(true);

                        TabLayout tabLayout = HomeFragment.tabLayout;
                        if (tabLayout != null) {
                            Objects.requireNonNull(tabLayout.getTabAt(0)).select();
                        }
                        return true;
                    case R.id.grade:
                        view.getGradeFragment().setUserVisibleHint(true);
                        FragmentUtils.showHide(view.getGradeFragment(), view.getTableFragment(), view.getHomeFragment(), view.getMineFragment());

                        return true;
                    case R.id.classTable:
                        view.getTableFragment().setUserVisibleHint(true);
                        FragmentUtils.showHide(view.getTableFragment(), view.getGradeFragment(), view.getHomeFragment(), view.getMineFragment());
                        return true;
                    case R.id.mine:
                        view.getMineFragment().setUserVisibleHint(true);
                        FragmentUtils.showHide(view.getMineFragment(), view.getGradeFragment(), view.getTableFragment(), view.getHomeFragment());
                        return true;
                }
                return false;
            }
        });

    }

}
