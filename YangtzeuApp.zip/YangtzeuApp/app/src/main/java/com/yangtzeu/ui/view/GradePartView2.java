package com.yangtzeu.ui.view;

import android.support.v7.widget.RecyclerView;
import android.widget.TextView;

import com.scwang.smartrefresh.layout.SmartRefreshLayout;
import com.yangtzeu.entity.PointBean;
import com.yangtzeu.ui.adapter.PointAdapter;

import java.util.List;

public interface GradePartView2 {

    SmartRefreshLayout getRefresh();

    RecyclerView getRecyclerView();

    PointAdapter getPointAdapter();

    TextView getAllNumberView();

    TextView getAllScoreView();

    TextView getAllPointView();

    List<PointBean> getGradeBeans();
}
