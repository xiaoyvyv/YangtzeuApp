package com.yangtzeu.ui.fragment;

import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.design.widget.TabLayout;
import android.support.v7.widget.RecyclerView;
import android.support.v7.widget.Toolbar;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;

import com.scwang.smartrefresh.layout.SmartRefreshLayout;
import com.scwang.smartrefresh.layout.api.RefreshLayout;
import com.scwang.smartrefresh.layout.listener.OnRefreshListener;
import com.yangtzeu.R;
import com.yangtzeu.entity.Course;
import com.yangtzeu.presenter.TablePresenter;
import com.yangtzeu.ui.activity.base.BaseFragment;
import com.yangtzeu.ui.adapter.TableFragmentAdapter;
import com.yangtzeu.ui.view.TableView;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by Administrator on 2018/3/6.
 */

public class TableFragment extends BaseFragment implements TableView {
    // 标志位，标志已经初始化完成。
    private boolean isPrepared = false;
    private Toolbar toolbar;
    private View rootView;
    private TabLayout tabLayout;
    private LinearLayout week_layout;
    private RecyclerView recyclerView;
    private TablePresenter presenter;
    private SmartRefreshLayout refreshLayout;
    private TableFragmentAdapter adapter;
    public List<Course> courses = new ArrayList<>();

    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        rootView = inflater.inflate(R.layout.fragment_table, container, false);
        findViews();
        isPrepared = true;
        lazyLoad();
        return rootView;
    }

    @Override
    public void findViews() {
        recyclerView = rootView.findViewById(R.id.recyclerView);
        toolbar = rootView.findViewById(R.id.toolbar);
        week_layout = rootView.findViewById(R.id.week_layout);
        refreshLayout = rootView.findViewById(R.id.refreshLayout);
        tabLayout = rootView.findViewById(R.id.tabLayout);
    }

    @Override
    public void setEvents() {
        adapter = new TableFragmentAdapter(getActivity());
        presenter = new TablePresenter(getActivity(), this);
        recyclerView.setNestedScrollingEnabled(false);
        recyclerView.setAdapter(adapter);

        presenter.setWithTabLayout();


        refreshLayout.setEnableLoadMore(false);
        refreshLayout.setOnRefreshListener(new OnRefreshListener() {
            @Override
            public void onRefresh(RefreshLayout refreshLayout) {
                courses.clear();
                adapter.clear();
                presenter.loadTableData();
            }
        });
    }

    @Override
    public Toolbar getToolbar() {
        return toolbar;
    }

    @Override
    public LinearLayout getWeekLayout() {
        return week_layout;
    }

    @Override
    public RecyclerView getRecyclerView() {
        return recyclerView;
    }

    @Override
    public List<Course> getCourse() {
        return courses;
    }

    @Override
    public SmartRefreshLayout getRefreshLayout() {
        return refreshLayout;
    }

    @Override
    public TabLayout getTabLayout() {
        return tabLayout;
    }

    @Override
    public TableFragmentAdapter getTableFragmentAdapter() {
        return adapter;
    }


    @Override
    protected void lazyLoad() {
        if (!isPrepared || !isVisible) {
            return;
        }
        if (!isLoadFinish) {
            setEvents();
            isLoadFinish = true;
        }
    }
}
