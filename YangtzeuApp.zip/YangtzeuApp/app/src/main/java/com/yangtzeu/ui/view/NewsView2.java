package com.yangtzeu.ui.view;

import android.support.v7.widget.RecyclerView;

import com.scwang.smartrefresh.layout.SmartRefreshLayout;
import com.yangtzeu.entity.NewsBean;
import com.yangtzeu.ui.adapter.NewsAdapter;

import java.util.List;

public interface NewsView2 {
    RecyclerView getRecyclerView();

    List<NewsBean> getData();
    String getUrlParam();
    int getPage();
    NewsAdapter getNewsAdapter();

    String getKind();
    SmartRefreshLayout getSmartRefreshLayout();
}
