package com.yangtzeu.model.imodel;

import android.app.Activity;

import com.yangtzeu.ui.view.HomePartView2;

public interface IHomePart2Model {

    void fitView(Activity activity, HomePartView2 view);
}
