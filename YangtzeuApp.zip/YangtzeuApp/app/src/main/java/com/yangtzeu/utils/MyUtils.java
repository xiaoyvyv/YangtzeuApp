package com.yangtzeu.utils;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.app.AlertDialog;
import android.app.ProgressDialog;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.os.Build;
import android.os.Environment;
import android.os.Vibrator;
import android.provider.MediaStore;
import android.support.v4.content.FileProvider;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.text.TextUtils;
import android.text.format.Formatter;
import android.util.Base64;
import android.view.View;
import android.webkit.MimeTypeMap;
import android.widget.ImageView;

import com.blankj.utilcode.util.ActivityUtils;
import com.blankj.utilcode.util.FileUtils;
import com.blankj.utilcode.util.LogUtils;
import com.blankj.utilcode.util.ObjectUtils;
import com.blankj.utilcode.util.PathUtils;
import com.blankj.utilcode.util.ToastUtils;
import com.blankj.utilcode.util.ZipUtils;
import com.bumptech.glide.Glide;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.reflect.TypeToken;
import com.tencent.smtt.sdk.CookieManager;
import com.tencent.smtt.sdk.QbSdk;
import com.yangtzeu.R;
import com.yangtzeu.entity.ImageBean;
import com.yangtzeu.ui.activity.ImageActivity;
import com.yangtzeu.ui.activity.WebActivity;

import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.lang.reflect.Field;
import java.math.BigDecimal;
import java.math.RoundingMode;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Collections;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Random;
import java.util.concurrent.atomic.AtomicReferenceFieldUpdater;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Created by 2016 on 2017/11/29.
 */

public class MyUtils {
    private final static String NameList[] = {"doc", "docx", "ppt", "pptx", "xls", "xlsx", "pdf", "txt", "epub"};
    private final static String ImageList[] = {"png", "jpg", "gif", "webp", "bmp", "jpeg"};


    public static void setToolbarBackToHome(final AppCompatActivity activity, Toolbar toolbar) {
        activity.setSupportActionBar(toolbar);
        Objects.requireNonNull(activity.getSupportActionBar()).setDisplayHomeAsUpEnabled(true);
        toolbar.setNavigationOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                activity.onBackPressed();
                activity.overridePendingTransition(R.anim.slide_in_right, R.anim.slide_out_left);
            }
        });
    }

    /**
     * 保留几位小数
     *
     * @param big 要进行保留的大数
     * @return 保留后的数
     */
    public static double getScale(double big, int Accuracy) {
        double result = 0;
        try {
            BigDecimal bigDecimal = new BigDecimal(big);
            result = bigDecimal.setScale(Accuracy, RoundingMode.HALF_UP).doubleValue();
        } catch (Exception e) {
            e.printStackTrace();
        }
        return result;
    }


    public static void startActivity(Class<? extends Activity> activity) {
        ActivityUtils.startActivity(activity);
        MyUtils.enterAnimation(ActivityUtils.getTopActivity());
    }

    public static void startActivity(Intent intent) {
        ActivityUtils.startActivity(intent);
        MyUtils.enterAnimation(ActivityUtils.getTopActivity());
    }

    public static ProgressDialog getProgressDialog(Context context, String s) {
        ProgressDialog progressDialog;
        progressDialog = new ProgressDialog(context);
        progressDialog.setTitle(context.getString(R.string.trip));
        progressDialog.setMessage(s);
        progressDialog.setCanceledOnTouchOutside(false);
        progressDialog.setCancelable(false);
        return progressDialog;
    }

    public static AlertDialog getAlert(Context context, String message, DialogInterface.OnClickListener listener) {
        AlertDialog.Builder build = new AlertDialog.Builder(context);
        build.setTitle(R.string.trip);
        build.setMessage(message);
        build.setPositiveButton(R.string.done, listener);
        build.setNegativeButton(R.string.clear, listener);
        build.create();
        AlertDialog dialog = build.create();
        dialog.setCanceledOnTouchOutside(false);
        return dialog;
    }

    public static AlertDialog getAlert(Context context, String message, DialogInterface.OnClickListener pos_listener, DialogInterface.OnClickListener neg_listener) {
        AlertDialog.Builder build = new AlertDialog.Builder(context);
        build.setTitle(R.string.trip);
        build.setMessage(message);
        build.setPositiveButton(R.string.done, pos_listener);
        build.setNegativeButton(R.string.clear, neg_listener);
        build.create();
        AlertDialog dialog = build.create();
        dialog.setCanceledOnTouchOutside(false);
        return dialog;
    }

    //保存网络文件
    public static void saveFile(final Context context, String url, String path, String saveFileName) {
        if (saveFileName.length() > 25) {
            saveFileName = saveFileName.substring(saveFileName.length() - 20, saveFileName.length());
        }
        if (path == null) {
            path = "A_Tool/Download/";
        }
        createSDCardDir(path);
        ToastUtils.showShort(R.string.saving);

        final String finalPath = path;
        final String finalSaveFileName = saveFileName;
        DownloadUtils.get().download(url, path, saveFileName, new DownloadUtils.OnDownloadListener() {
            @Override
            public void onDownloadSuccess() {
                ToastUtils.showShort(R.string.save_success);
                if (finalSaveFileName.endsWith(".png") || finalSaveFileName.endsWith(".jpg") || finalSaveFileName.endsWith(".jpeg") || finalSaveFileName.endsWith(".gif")) {
                    MyUtils.saveImageToGallery(context, PathUtils.getExternalStoragePath() + "/" + finalPath + finalSaveFileName);
                }
            }

            @Override
            public void onDownloading(int progress) {

            }

            @Override
            public void onDownloadFailed(String error) {
                LogUtils.e(error);
                ToastUtils.showShort(R.string.save_error);
            }
        });
    }

    /**
     * 正则获取Host
     *
     * @param url 链接
     * @return Host
     */
    public static String getHost(String url) {
        if (url == null || url.trim().equals("")) {
            return "";
        }
        String host = "";
        Pattern p = Pattern.compile("(?<=//|)((\\w)+\\.)+\\w+");
        Matcher matcher = p.matcher(url);
        if (matcher.find()) {
            host = matcher.group();
        }
        return host;
    }

    /**
     * 规则：必须同时包含大小写字母及数字
     *
     * @param str 被判断字符串
     * @return 是否同时包含大小写字母及数字
     */
    public static boolean isContainAll(String str) {
        boolean isDigit = false;//定义一个boolean值，用来表示是否包含数字
        boolean isLowerCase = false;//定义一个boolean值，用来表示是否包含字母
        boolean isUpperCase = false;
        for (int i = 0; i < str.length(); i++) {
            if (Character.isDigit(str.charAt(i))) {   //用char包装类中的判断数字的方法判断每一个字符
                isDigit = true;
            } else if (Character.isLowerCase(str.charAt(i))) {  //用char包装类中的判断字母的方法判断每一个字符
                isLowerCase = true;
            } else if (Character.isUpperCase(str.charAt(i))) {
                isUpperCase = true;
            }
        }
        String regex = "^[a-zA-Z0-9]+$";
        return isDigit && isLowerCase && isUpperCase && str.matches(regex);
    }


    /**
     * 获得根目录
     *
     * @return 根目录
     */
    public static String rootPath() {
        File sdcardDir = Environment.getExternalStorageDirectory();
        //得到一个路径，内容是sdcard的文件夹路径和名字
        String path = sdcardDir.getPath();
        return path + "/";
    }

    /**
     * 文件大小换算
     *
     * @param target_size 字节大小
     * @return 文件大小
     */
    public static String FormatSize(Context context, String target_size) {
        return Formatter.formatFileSize(context, Long.valueOf(target_size));
    }


    /**
     * 在SD卡上创建一个文件夹"A_Tool"
     *
     * @param DirName 文件夹名称
     */
    public static String createSDCardDir(String DirName) {
        String path = "";
        if (Environment.MEDIA_MOUNTED.equals(Environment.getExternalStorageState())) {
            // 创建一个文件夹对象，赋值为外部存储器的目录
            File sdcardDir = Environment.getExternalStorageDirectory();
            //得到一个路径，内容是sdcard的文件夹路径和名字
            path = sdcardDir.getPath() + "/" + DirName;
            File path1 = new File(path);
            if (!path1.exists()) {
                //若不存在，创建目录，可以在应用启动的时候创建
                if (path1.mkdirs()) {
                    LogUtils.i("文件夹路径创建成功：" + path);
                }
            } else {
                LogUtils.v("文件夹路径已存在：" + path);
            }
        } else {
            LogUtils.e("文件夹创建失败：" + DirName, "可能未取得读写权限");
        }
        return path;
    }

    /**
     * 根据扩展名获取文件Mime类型
     *
     * @param file 文件
     * @return 文件Mime类型
     */
    public static String getMimeType(File file) {
        String extension = FileUtils.getFileExtension(file);
        return MimeTypeMap.getSingleton().getMimeTypeFromExtension(extension);
    }


    /**
     * QB_SDK打开文件
     *
     * @param path 文件路径
     */
    public static void openFile(Context context, final String path) {
        if (path.endsWith(".zip")) {
            String zip_path = createSDCardDir("A_Tool/Download/Zip/");
            try {
                ZipUtils.unzipFile(path, zip_path);
                boolean delete = new File(path).delete();
                LogUtils.i(delete);
                String activity = ActivityUtils.getTopActivity().getLocalClassName();
                if (activity.contains("WebActivity")) {
                    ToastUtils.showShort("解压成功");
                    //ActivityUtils.startActivity(DownloadActivity.class);
                } else {
                    ToastUtils.showShort("解压成功，请刷新");
                }
            } catch (IOException e) {
                ToastUtils.showShort("解压失败");
                e.printStackTrace();
            }
            return;
        }
        boolean QB_canOpen = false;
        boolean Image_canOpen = false;
        String name = FileUtils.getFileExtension(path);
        for (String Item : NameList) {
            if (name.equals(Item)) {
                QB_canOpen = true;
            }
        }
        if (QB_canOpen) {
            LogUtils.e("QB_SDK:" + name, "尝试打开：" + path);
            QbSdk.openFileReader(context, path, null, null);
        } else {
            for (String Item : ImageList) {
                if (name.equals(Item)) {
                    Image_canOpen = true;
                }
            }
            if (Image_canOpen) {
                openImage(context,path);
            } else {
                openFileByPath(context, path);
            }
        }

    }

    /**
     * 传入路径，打开文件
     *
     * @param path 文件路径
     */

    public static void openFileByPath(Context context, String path) {
        LogUtils.e("尝试打开文件");
        try {
            File file = new File(path);
            String url_type = getMimeType(file);

            Intent intent = new Intent(Intent.ACTION_VIEW);
            intent.addCategory(Intent.CATEGORY_DEFAULT);
            intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
            intent.addFlags(Intent.FLAG_GRANT_WRITE_URI_PERMISSION);
            intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);

            Uri uri;
            //判读版本是否在7.0以上
            if (Build.VERSION.SDK_INT >= 24) {
                uri = FileProvider.getUriForFile(context, "com.yangtzeu", file);
            } else {
                uri = Uri.fromFile(file);
            }
            intent.setDataAndType(uri, url_type);

            context.startActivity(intent);
        } catch (Exception e) {
            AlertDialog dialog = new AlertDialog.Builder(context)
                    .setTitle("提示")
                    .setMessage("此App不支持打开此文件，请在手机文件管理器中打开路径\n\n\"A_Tool/Download/\"")
                    .setPositiveButton("知道了", null)
                    .create();
            dialog.show();
        }
    }

    /**
     * 获取取随机数
     *
     * @param num 最大数限制
     * @return 随机数`
     */
    public static String getRand(int num) {
        Random ran = new Random(System.currentTimeMillis());
        int refresh_int = ran.nextInt(num);
        String str = String.valueOf(refresh_int);
        LogUtils.i("获取的随机数为", str);
        return str;
    }

    /**
     * 复制内容到剪切板
     */
    public static void putStringToClipboard(Context context, String clipboard) {
        ClipboardManager mClipboardManager = (ClipboardManager) context.getSystemService(Context.CLIPBOARD_SERVICE);
        Objects.requireNonNull(mClipboardManager).setPrimaryClip(ClipData.newPlainText(null, clipboard));
    }

    /**
     * 复制内容到剪切板，定制弹出内容
     *
     * @param clipboard 复制内容
     * @param context   上下文
     * @param toast     弹出内容
     */
    public static void putStringToClipboard(Context context, String clipboard, String toast) {
        ClipboardManager mClipboardManager = (ClipboardManager) context.getSystemService(Context.CLIPBOARD_SERVICE);
        Objects.requireNonNull(mClipboardManager).setPrimaryClip(ClipData.newPlainText(null, clipboard));
        ToastUtils.showShort(toast);

    }

    /**
     * 重写对话框关闭事件
     *
     * @param dialogInterface 对话框
     * @param close           是否能关闭
     */
    public static void canCloseDialog(DialogInterface dialogInterface, boolean close) {
        try {
            Field field = Objects.requireNonNull(dialogInterface.getClass().getSuperclass()).getDeclaredField("mShowing");
            field.setAccessible(true);
            field.set(dialogInterface, close);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    /**
     * 判断是否是数字
     *
     * @param str 被判断的字符串
     * @return 是否是数字
     */
    public static boolean isNumeric(String str) {
        Pattern pattern = Pattern.compile("[0-9]*");
        return pattern.matcher(str).matches();
    }

    /**
     * 在浏览器中打开链接
     *
     * @param targetUrl 要打开的网址
     */
    public static void openBrowser(Context context, String targetUrl) {
        if (!TextUtils.isEmpty(targetUrl) && targetUrl.startsWith("file://")) {
            ToastUtils.showShort(R.string.cant_open);
            return;
        }
        Intent intent = new Intent();
        intent.setAction("android.intent.action.VIEW");
        Uri url = Uri.parse(targetUrl);
        intent.setData(url);
        context.startActivity(intent);
    }

    /**
     * 将cookie同步到X5WebView
     *
     * @param host   WebView要加载的host
     * @param cookie 要同步的cookie
     */
    @SuppressLint("ObsoleteSdkInt")
    public static void syncX5Cookie(String host, String cookie) {
        CookieManager cookieManager = CookieManager.getInstance();
        cookieManager.setCookie(host, cookie);
    }

    /**
     * 分享文件
     *
     * @param what 分享内容
     */
    public static void shareText(Context context, String what) {
        Intent share = new Intent();
        share.setAction(Intent.ACTION_SEND);
        share.putExtra(Intent.EXTRA_TEXT, "分享了：\n" + what);
        share.setType("text/plain");
        context.startActivity(Intent.createChooser(share, "分享到"));
        enterAnimation(context);
    }

    /**
     * 读取Assets内部文件
     *
     * @param fileName Assets内部文件路径
     * @return 文件内容
     */
    public static String readAssetsFile(Context context, String fileName) {
        try {
            InputStream is = context.getAssets().open(fileName);
            int size = is.available();
            byte[] buffer = new byte[size];
            int read = is.read(buffer);
            LogUtils.i(read);
            is.close();
            return new String(buffer, "utf-8");
        } catch (IOException e) {
            e.printStackTrace();
        }
        return "读取错误，请检查文件";
    }

    /**
     * 获取App版本号
     *
     * @return App版本号
     */
    public static String getAPPVersionName(Context context) {
        String appVersionName = "";
        float currentVersionCode;
        PackageManager manager = context.getPackageManager();
        try {
            PackageInfo info = manager.getPackageInfo(context.getPackageName(), 0);
            appVersionName = info.versionName; // 版本名
            currentVersionCode = info.versionCode; // 版本号
            System.out.println(currentVersionCode + " " + appVersionName);
        } catch (PackageManager.NameNotFoundException e) {
            e.printStackTrace();
        }
        return appVersionName;
    }

    /**
     * 获取时间信息
     *
     * @param Calendar_What 信息种类
     * @return 时间信息
     */
    public static String getDateInfo(int Calendar_What) {
        int mYear, mMonth, mDay, mWay, mHour, mMinute;
        Calendar c = Calendar.getInstance();
        switch (Calendar_What) {
            case Calendar.YEAR:
                mYear = c.get(Calendar.YEAR); // 获取当前年份
                return String.valueOf(mYear);
            case Calendar.MONTH:
                mMonth = c.get(Calendar.MONTH) + 1;// 获取当前月份
                return String.valueOf(mMonth);
            case Calendar.DAY_OF_MONTH:
                mDay = c.get(Calendar.DAY_OF_MONTH);// 获取当日期
                return String.valueOf(mDay);
            case Calendar.DAY_OF_WEEK:
                mWay = c.get(Calendar.DAY_OF_WEEK);// 获取当前星期
                return String.valueOf(mWay);
            case Calendar.HOUR_OF_DAY:
                mHour = c.get(Calendar.HOUR_OF_DAY);//时
                return String.valueOf(mHour);
            case Calendar.MINUTE:
                mMinute = c.get(Calendar.MINUTE);//分
                return String.valueOf(mMinute);
            default:
                return (c.get(Calendar.MONTH) + 1) + "-" + c.get(Calendar.DAY_OF_MONTH) + " " + c.get(Calendar.HOUR_OF_DAY) + ":" + c.get(Calendar.MINUTE);
        }
    }

    /**
     * 加载图片
     *
     * @param imageView 图片容器
     * @param o         图片内容（链接、文件等等）
     */
    public static void loadImage(Context context, ImageView imageView, Object o) {
        if (ObjectUtils.isNotEmpty(context)) {
            if (context instanceof Activity) {
                if (((Activity) context).isDestroyed()) {
                    return;
                }
            }
            Glide.with(context).load(o).into(imageView);
        }
    }

    /**
     * 图书馆相关方法
     *
     * @param whichJson whichJson
     * @param key       key
     * @return getBookStateInfo
     */
    public static String getBookStateInfo(Context context, int whichJson, String key) {
        switch (whichJson) {
            case 0:
                String Map0 = readAssetsFile(context, "LibState/BookState.json");
                Map<String, String> Hash0 = parseData(Map0);
                return Hash0.get(key);
            case 1:
                String Map1 = readAssetsFile(context, "LibState/WhereLib.json");
                Map<String, String> Hash1 = parseData(Map1);
                return Hash1.get(key);
            case 2:
                String Map2 = readAssetsFile(context, "LibState/WhichCollege.json");
                Map<String, String> Hash2 = parseData(Map2);
                return Hash2.get(key);
        }
        return null;
    }

    private static Map<String, String> parseData(String data) {
        GsonBuilder gb = new GsonBuilder();
        Gson g = gb.create();
        return g.fromJson(data, new TypeToken<Map<String, String>>() {
        }.getType());
    }

    /**
     * 控制震动
     *
     * @param time 震动时间
     */
    public static void mVibrator(Context context, int time) {
        Vibrator vibrator = (Vibrator) context.getSystemService(Context.VIBRATOR_SERVICE);
        long[] pattern = {0, time}; //0ms—500ms
        Objects.requireNonNull(vibrator).vibrate(pattern, -1);
    }

    /**
     * 十进制转为16进制
     *
     * @param a 10进制数
     * @return 16进制数
     */
    public static String formattingH(int a) {
        String i = Integer.toHexString(a);
        if (i.length() != 2) {
            i = "0" + i;
        }
        return i;
    }

    /**
     * 拨打电话
     *
     * @param phone 电话号码
     */
    public static void Call(Context context, String phone) {
        Uri uri = Uri.parse("tel:" + phone); //设置要操作的路径
        Intent intent = new Intent();
        intent.setAction(Intent.ACTION_DIAL);  //设置要操作的Action
        intent.setData(uri); //要设置的数据
        context.startActivity(intent);
        enterAnimation(context);
    }

    /**
     * QQ会话
     *
     * @param qq QQ号码
     */
    public static void chatQQ(Context context, String qq) {
        String qq_str = "mqqwpa://im/chat?chat_type=wpa&uin=" + qq + "&version=1";
        Uri uri = Uri.parse(qq_str); //设置要操作的路径
        Intent intent = new Intent();
        intent.setData(uri); //要设置的数据
        context.startActivity(intent);
        enterAnimation(context);
    }

    /**
     * 拖动排序，第adapterPosition个调到第position个，然后其他的顺延
     *
     * @param list_Title   数组
     * @param fromPosition 从哪个位置调
     * @param toPosition   调到哪个位置
     */
    public static void ListSwap(List<?> list_Title, int fromPosition, int toPosition) {
        if (fromPosition > toPosition) {
            for (int i = fromPosition; i > toPosition; i--) {
                Collections.swap(list_Title, i, i - 1);// 改变实际的数据集
            }
        } else {
            for (int i = fromPosition; i < toPosition; i++) {
                Collections.swap(list_Title, i + 1, i);// 改变实际的数据集
            }
        }
    }


    /**
     * 过滤emoji 或者 其他非文字类型的字符
     *
     * @param source 被过滤文本
     * @return 过滤后文本
     */
    public static String filterEmoji(String source) {
        int len = source.length();
        StringBuilder buf = new StringBuilder(len);
        for (int i = 0; i < len; i++) {
            char codePoint = source.charAt(i);
            if (isNotEmojiCharacter(codePoint)) {
                buf.append(codePoint);
            }
        }
        return buf.toString();
    }

    private static boolean isNotEmojiCharacter(char codePoint) {
        return codePoint == 0x0 || codePoint == 0x9 || codePoint == 0xA || codePoint == 0xD || codePoint >= 0x20 && codePoint <= 0xD7FF || codePoint >= 0xE000 && codePoint <= 0xFFFD;
    }

    /**
     * 跳转网页
     *
     * @param url 网页链接
     */
    public static void openUrl(Context context, String url) {
        context.startActivity(new Intent(context, WebActivity.class)
                .putExtra("from_url", url));
        enterAnimation(context);
    }

    public static void enterAnimation(Context context) {
        if (context instanceof Activity) {
            Activity activity = (Activity) context;
            activity.overridePendingTransition(android.R.anim.slide_in_left, android.R.anim.slide_out_right);
        }
    }

    /**
     * 跳转网页
     *
     * @param url 网页链接
     */
    public static void openUrl(Context context, String url, boolean isNoTitle) {
        context.startActivity(new Intent(context, WebActivity.class)
                .putExtra("from_url", url)
                .putExtra("isNoTitle", isNoTitle));
        enterAnimation(context);
    }

    /**
     * 跳转网页
     *
     * @param base_url  base_url
     * @param base_html base_html
     */
    public static void openBaseUrl(Context context, String base_title, String base_url, String base_html) {
        context.startActivity(new Intent(context, WebActivity.class)
                .putExtra("base_title", base_title)
                .putExtra("base_url", base_url)
                .putExtra("base_html", base_html));
        enterAnimation(context);
    }

    /**
     * 跳转网页
     *
     * @param base_url  base_url
     * @param base_html base_html
     */
    public static void openBaseUrl(Context context, String base_url, String base_html, boolean isNoTitle) {
        context.startActivity(new Intent(context, WebActivity.class)
                .putExtra("base_url", base_url)
                .putExtra("isNoTitle", isNoTitle)
                .putExtra("base_html", base_html));
        enterAnimation(context);
    }

    /**
     * 跳转网页
     *
     * @param url    网页链接
     * @param cookie Cookie
     */
    public static void openUrl(Context context, String url, String cookie) {
        context.startActivity(new Intent(context, WebActivity.class)
                .putExtra("from_url", url)
                .putExtra("cookie", cookie));
        enterAnimation(context);
    }

    /**
     * 打开图片
     *
     * @param bean 图片资源
     */
    public static void openImage(Context context, ImageBean bean) {
        Intent intent = new Intent(context, ImageActivity.class);
        intent.putExtra("image_list", bean);
        context.startActivity(intent);
        enterAnimation(context);
    }

    public static void openImage(Context context, String url) {
        String[] trip = {url};
        openImage(context, ImageBean.getImageBean(trip, trip));
    }

    /**
     * @param string base64值
     * @return 返回类型
     */
    public static Bitmap base64ToBitmap(String string) {
        Bitmap bitmap = null;
        try {
            byte[] bitmapArray = Base64.decode(string.split(",")[1], Base64.DEFAULT);
            bitmap = BitmapFactory.decodeByteArray(bitmapArray, 0, bitmapArray.length);
        } catch (Exception e) {
            e.printStackTrace();
        }
        return bitmap;
    }

    public static void saveImageToGallery(Context context, String path) {
        LogUtils.e("图片更新路径" + path);
        File file = new File(path);
        // 其次把文件插入到系统图库
        try {
            MediaStore.Images.Media.insertImage(context.getContentResolver(),
                    file.getAbsolutePath(), file.getName(), "网页图片");
        } catch (Exception e) {
            ToastUtils.showShort("更新失败");
            e.printStackTrace();
        }
        //最后通知图库更新
        Intent intent = new Intent();
        intent.setAction(Intent.ACTION_MEDIA_SCANNER_SCAN_FILE);//扫描单个文件
        intent.setData(Uri.fromFile(file));//给图片的绝对路径
        context.sendBroadcast(intent);
    }

    public static File geCacheDir() {
        String path = MyUtils.createSDCardDir("A_Tool/Cache/");
        return new File(path);
    }

    //正则表达式匹配两个指定字符串中间的内容
    public static List<String> getSubUtil(String soap, String regex) {
        List<String> list = new ArrayList<>();
        Pattern pattern = Pattern.compile(regex);// 匹配的模式
        Matcher m = pattern.matcher(soap);
        while (m.find()) {
            int i = 1;
            list.add(m.group(i));
        }
        return list;
    }

    //获取QQ头像
    public static String getQQHeader(String qq) {
        return "http://q1.qlogo.cn/g?b=qq&nk=" + qq + "&s=100";
    }

}
