package com.yangtzeu.ui.adapter;

import android.annotation.SuppressLint;
import android.content.Context;
import android.support.annotation.NonNull;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.blankj.utilcode.util.ToastUtils;
import com.yangtzeu.R;
import com.yangtzeu.entity.MessageBean;

import java.util.ArrayList;
import java.util.List;


/**
 * Created by Administrator on 2018/4/12.
 *
 * @author 王怀玉
 * @explain MoreAdapter
 */

public class MessageAdapter extends RecyclerView.Adapter<MessageAdapter.ViewHolder> {
    private Context context;
    private List<MessageBean.DataBean> dataBeans = new ArrayList<>();

    public MessageAdapter(Context context) {
        this.context = context;
    }

    public void setData( List<MessageBean.DataBean>  dataBeans) {
        this.dataBeans = dataBeans;
    }

    public void clear() {
        dataBeans.clear();
        notifyDataSetChanged();
    }


    @SuppressLint("InflateParams")
    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        return new ViewHolder(LayoutInflater.from(context).inflate(R.layout.activity_message_item, parent, false));
    }

    @SuppressLint("SetTextI18n")
    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        final MessageBean.DataBean bean = dataBeans.get(position);
        holder.title.setText(bean.getText());
        holder.time.setText("发布时间：" + bean.getTime());
        holder.from.setText("发布者："+bean.getFrom());

        if (bean.getFrom().contains("admin")) {
            holder.from.setTextColor(context.getResources().getColor(R.color.red));
        } else {
            holder.from.setTextColor(context.getResources().getColor(R.color.black));
        }
        holder.onclick.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                ToastUtils.showShort(bean.getText());
            }
        });
    }

    @Override
    public long getItemId(int i) {
        return super.getItemId(i);
    }

    @Override
    public int getItemCount() {
        return dataBeans.size();
    }

    @Override
    public int getItemViewType(int position) {
        return super.getItemViewType(position);
    }

    class ViewHolder extends RecyclerView.ViewHolder {
        TextView title;
        TextView time;
        TextView from;
        RelativeLayout onclick;
        ViewHolder(View view) {
            super(view);
            time = view.findViewById(R.id.time);
            onclick = view.findViewById(R.id.onclick);
            from = view.findViewById(R.id.from);
            title = view.findViewById(R.id.title);
        }
    }

}