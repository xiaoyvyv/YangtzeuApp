package com.yangtzeu.ui.fragment;

import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.design.widget.TabLayout;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.view.ViewPager;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.RelativeLayout;

import com.blankj.utilcode.util.FragmentUtils;
import com.yangtzeu.R;
import com.yangtzeu.presenter.GradePresenter;
import com.yangtzeu.ui.activity.base.BaseFragment;
import com.yangtzeu.ui.adapter.FragmentAdapter;
import com.yangtzeu.ui.view.GradeView;

import java.util.Objects;

/**
 * Created by Administrator on 2018/3/6.
 */

public class GradeFragment extends BaseFragment implements GradeView {
    // 标志位，标志已经初始化完成。
    public boolean isPrepared = false;
    public View rootView;
    private ViewPager pager;
    private TabLayout tab;
    private FragmentAdapter fragmentAdapter;

    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        rootView = inflater.inflate(R.layout.fragment_grade, container, false);
        findViews();
        isPrepared = true;
        lazyLoad();
        return rootView;
    }

    @Override
    public void findViews() {
        pager = rootView.findViewById(R.id.pager);
        tab = rootView.findViewById(R.id.tab);
    }

    @Override
    public void setEvents() {
        //设置Fragment适配器
        fragmentAdapter = new FragmentAdapter(Objects.requireNonNull(getActivity()).getSupportFragmentManager());

        GradePresenter presenter = new GradePresenter(getActivity(), this);
        presenter.setViewPager();
    }

    @Override
    protected void lazyLoad() {
        if (!isPrepared || !isVisible) {
            return;
        }
        if (!isLoadFinish) {
            setEvents();
            isLoadFinish = true;
        }
    }


    @Override
    public FragmentAdapter getAdapter() {
        return fragmentAdapter;
    }

    @Override
    public ViewPager getViewPager() {
        return pager;
    }

    @Override
    public TabLayout getTabLayout() {
        return tab;
    }
}
