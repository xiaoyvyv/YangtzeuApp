package com.yangtzeu.ui.activity;

import android.os.Bundle;
import android.support.annotation.Nullable;

import com.yangtzeu.ui.activity.base.BaseActivity;
import com.yangtzeu.utils.MyUtils;

public class JwcListActivity extends BaseActivity {
    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
    }

    @Override
    public void findViews() {

    }

    @Override
    public void setEvents() {
        MyUtils.startActivity(MainActivity.class);
    }
}
