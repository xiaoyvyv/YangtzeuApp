package com.yangtzeu.ui.view;

import android.support.design.widget.TabLayout;
import android.support.v7.widget.RecyclerView;
import android.support.v7.widget.Toolbar;
import android.widget.LinearLayout;

import com.scwang.smartrefresh.layout.SmartRefreshLayout;
import com.yangtzeu.entity.Course;
import com.yangtzeu.ui.adapter.TableFragmentAdapter;

import java.util.List;

public interface TableView {
    Toolbar getToolbar();

    LinearLayout getWeekLayout();

    RecyclerView getRecyclerView();

    List<Course> getCourse();

    SmartRefreshLayout getRefreshLayout();

    TabLayout getTabLayout();

    TableFragmentAdapter getTableFragmentAdapter();
}
